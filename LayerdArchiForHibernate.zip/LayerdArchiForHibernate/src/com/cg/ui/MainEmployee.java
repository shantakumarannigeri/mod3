package com.cg.ui;

import com.cg.entity.Employee;
import com.cg.service.EmployeeServiceImp;

public class MainEmployee {
public static void main(String[] args) {
	

EmployeeServiceImp empi=new EmployeeServiceImp();

Employee employee=new Employee();
employee.setName("krishna");
empi.addEmployee(employee);
System.out.println("Added one employee to database.");


Employee employee1=empi.getEmployeebyId(10);
System.out.print("ID:"+employee1.getEmployeeId());
System.out.println(" Name:"+employee1.getName());



empi.removeEmployee(employee);
System.out.println("End of program...");

}
}