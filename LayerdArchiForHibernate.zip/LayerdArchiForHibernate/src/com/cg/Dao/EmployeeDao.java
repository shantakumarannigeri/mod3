package com.cg.Dao;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.entity.Employee;


public interface EmployeeDao {
	
	public abstract void addEmployee(Employee employee);
	public abstract void removeEmployee(Employee employee);
	public abstract Employee getEmployeebyId(int employeeId);
//	public abstract void updateStudent(Student student);
	

}
