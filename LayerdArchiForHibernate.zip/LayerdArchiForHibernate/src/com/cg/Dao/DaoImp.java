package com.cg.Dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.entity.Employee;

public class DaoImp implements EmployeeDao{
EntityManagerFactory factory = Persistence.createEntityManagerFactory("myunit");
	
	EntityManager em = factory.createEntityManager();
	
	
	@Override
	public void addEmployee(Employee employee) {
		em.getTransaction().begin();
		em.persist(employee);
		//em.getTransaction().commit();
		
		
		
		
	}
	@Override
	public Employee getEmployeebyId(int employeeId) {
		Employee employee=em.find(Employee.class, employeeId);
		return employee;
	}



	@Override
	public void removeEmployee(Employee employee) {
		em.remove(employee);
		em.getTransaction().commit();
		em.close();
		factory.close();
		
		
	}


	
}
