package com.cg.service;

import com.cg.Dao.DaoImp;
import com.cg.Dao.EmployeeDao;
import com.cg.entity.Employee;

public class EmployeeServiceImp implements EmployeeService {
	DaoImp dao=new DaoImp();

	@Override
	public void addEmployee(Employee employee) {
		dao.addEmployee(employee);
	}

	@Override
	public void removeEmployee(Employee employee) {
	dao.removeEmployee(employee);
		
	}

	@Override
	public Employee getEmployeebyId(int employeeId) {
	Employee employee=dao.getEmployeebyId(employeeId);
		return employee;
	}

}
