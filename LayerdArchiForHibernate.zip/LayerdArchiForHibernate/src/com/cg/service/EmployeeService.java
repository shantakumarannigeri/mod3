package com.cg.service;

import com.cg.entity.Employee;

public interface EmployeeService {
	public abstract void addEmployee(Employee employee);
	public abstract void removeEmployee(Employee employee);
	public abstract Employee getEmployeebyId(int employeeId);
//	public abstract void updateStudent(Student student);
}
